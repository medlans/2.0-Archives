README

Please see the PicoCricket website for the latest information and documentation http://www.picocricket.com/

