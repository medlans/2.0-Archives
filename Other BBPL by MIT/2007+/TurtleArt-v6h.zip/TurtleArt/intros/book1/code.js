var index;

function setup(){
        var loc = location.hash.substr(1);
	if(loc.length==0) index=0;
	else index = parseInt(loc);
	document.title = images[index][0];
	var img = document.getElementById('img-to-fill-in');
	img.src = 'images/'+images[index][1]+'.img.png';
}

