function setup(){
	var div = document.getElementById('div-to-fill-in');
	divstyle(div);
	for (i in images) addImage(div, images[i][0],images[i][1],i);
	if(div.addEventListener) div.addEventListener("click", clickHandler, true);
	else div.attachEvent('onclick', clickHandler);
}

function addImage(parent, name, fname, index){
	var div = document.createElement('div');
	var img = document.createElement('img');
	img.src = 'images/'+fname+'.thb.png';
	img.setAttribute('imgindex',index);
	thumbstyle(img);
	div.appendChild(img);
	var p = document.createElement('p');
	p.appendChild(document.createTextNode(name));
	framelabelstyle(p);
	div.appendChild(p);
	gridstyle(div);
	parent.appendChild(div);	
}	
	
function clickHandler(event){
	var idx
	if(window.event) idx = window.event.srcElement.getAttribute('imgindex');
	else idx = event.target.getAttribute('imgindex');
	if(idx==null) return;
	window.location.href = 'imagepage.html#'+idx;
}
