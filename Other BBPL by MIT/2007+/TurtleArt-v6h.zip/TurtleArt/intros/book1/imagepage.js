var index;

function setup(){
	index = parseInt(location.hash.substr(1));
	var names = images[index];
	document.title = names[0];
	var img = document.getElementById('img-to-fill-in');
	img.src = 'images/'+names[1]+'.png';
	var p = document.getElementById('p-to-fill-in');
	p.appendChild(document.createTextNode(names[0]));
//	var n = document.getElementById('buyname');
//	n.value = names[0];
}

function showcode(){
	window.location='code.html#'+index;
}

