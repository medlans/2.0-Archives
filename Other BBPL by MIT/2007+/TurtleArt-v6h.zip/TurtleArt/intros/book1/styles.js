// frame page

var framewidth = '850px';

function divstyle(e){
	var s=e.style;	
	s.marginLeft = 'auto';
	s.marginRight = 'auto';
	s.width = framewidth;
}

function thumbstyle(e){
	var s=e.style;	
	s.cursor = 'pointer';
	s.width = '120px';
	s.height = '96px';
}

function framelabelstyle(e){
	var s=e.style;	
	s.textAlign = "center";	
	s.margin = '0px';	
	s.marginTop = '-2px';	
	s.cursor = 'default';
	}

function gridstyle(e){
	var s=e.style;	
	s.cssFloat = 'left';	
	s.styleFloat = 'left';		
	s.padding = '4px';	
	s.border = '1px solid #808080';	
	s.marginBottom = '-1px';	
	s.marginRight = '-1px';
}

