var pages = [

['size','<b>set pensize</b><br>changes the thickness of the turtle\'s pen'],
['pupd','<b>pd, pu</b><br>pen down (pd) to draw while moving <br> pen up (pu) to move without drawing'],
['circles', '<b>arc</b><br>draws an arc <br>radius is how big<br>angle is how much of the circle'],
['where', '<b>setxy</b><br>sets the turtle\'s horizontal (x) and vertical (y) position'],
['xcoor', '<b>xcor</b><br>is the turtle\'s horizontal position'],
['setshade', '<b>set shade</b><br>for a lighter or darker color'],
['shade', '<b>shade</b>'],
['fillscreen', '<b>fillscreen</b> <br>fills the background with a color and a shade'],
['filled', '<b>start fill, end fill </b><br>indicates the beginning and end of a shape to fill'],
['random', '<b>random</b><br>picks a value between two numbers'],
['oneof', '<b>oneof</b><br>chooses one of two numbers'],
['heading', '<b>heading</b><br>is the turtle\'s direction'],
['cleanblock', '<b>clean</b> <br>cleans everything on the screen']

]
