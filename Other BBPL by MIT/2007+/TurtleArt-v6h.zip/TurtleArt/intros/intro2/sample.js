var index;
var currenthref;

function setup(){
	setInterval(checkHref, 300);
	showpage();
}

function showpage(){
	var loc = location.hash.substr(1);
	if(loc.length==0) index=0;
	else index = parseInt(loc);
	var img = document.getElementById('img-to-fill-in');
	img.src = 'images/'+pages[index][0]+'.img.png';
	img.onload = setexplanation;
	currenthref = location.hash;
}

function setexplanation(){
	var p = document.getElementById('p-to-fill-in');
	p.innerHTML = pages[index][1];
}

function next(){
	var next = index+1;
	if(next==pages.length) next=0;
	window.location = 'index.html#'+next;
	showpage();
}

function next(){
	var next = index+1;
	if(next==pages.length) window.location = '../index.html';
	else window.location = 'index.html#'+next;
	showpage();
}

function checkHref(){
	if(currenthref!=location.hash) showpage();
}
