#include <pango/pangocairo.h>
#include <glib/gprintf.h>
#include <string.h>

void pango2DrawString(char *utf8, int utf8Length, int *wPtr, int *hPtr, unsigned char *bitmapPtr);
void pango2MeasureString(char *utf8, int utf8Length, int *wPtr, int *hPtr, int *layoutDetailsPtr);
void pango2SetColors(int fgRed, int fgGreen, int fgBlue, int bgRed, int bgGreen, int bgBlue, int mapBGToTransparent);
void pango2SetFont(char *fontName, int fontSize, int boldFlag, int italicFlag, int antiAliasFlag);
void pango2SetLanguage(char* lang);

PangoLayout *cachedLayout = NULL;  // used for measuring
PangoFontDescription *fontDescr = NULL;
cairo_font_options_t* fontOptions = NULL;
char language[100] = "";

int transparentBGFlag = 0;
double bgR = 1.0, bgG = 1.0, bgB = 1.0;
double fgR = 0.0, fgG = 0.0, fgB = 0.01;
int bgRGB = 0xffffff;

void pango2SetLanguage(char* lang) {
	strncpy(language, lang, 100);
}

void pango2SetColors(int fgRed, int fgGreen, int fgBlue, int bgRed, int bgGreen, int bgBlue, int mapBGToTransparent) {
	fgR = fgRed / 255.0; fgG = fgGreen / 255.0; fgB = fgBlue / 255.0;
	bgR = bgRed / 255.0; bgG = bgGreen / 255.0; bgB = bgBlue / 255.0;
	bgRGB = (bgRed << 16) | (bgGreen << 8) | bgBlue;
	transparentBGFlag = mapBGToTransparent;
}

void pango2SetFont(char *fontName, int fontSize, int boldFlag, int italicFlag, int antiAliasFlag) {
	char description[200];
	g_sprintf(description, "%s, %s %s %dpx",
		fontName,
		(boldFlag ? "bold" : ""),
		(italicFlag ? "italic" : ""),
		fontSize);

	if (fontDescr != NULL) pango_font_description_free(fontDescr);
	fontDescr = pango_font_description_from_string(description);

	if (fontOptions == NULL) {
		fontOptions = cairo_font_options_create();
		// Note: On Mac OS, the default hint style and metrics looked the best. Also, using
		// the default allows the user to control the look via the OS settings.
		/*
		styles:
			CAIRO_HINT_STYLE_DEFAULT		Use the default hint style for for font backend and target device
			CAIRO_HINT_STYLE_NONE				Do not hint outlines
			CAIRO_HINT_STYLE_SLIGHT			Hint outlines slightly to improve contrast while retaining good fidelity to the original shapes.
			CAIRO_HINT_STYLE_MEDIUM			Hint outlines with medium strength giving a compromise between fidelity to the original shapes and contrast
			CAIRO_HINT_STYLE_FULL				Hint outlines to maximize contrast
		metrics:
			CAIRO_HINT_METRICS_DEFAULT	Hint metrics in the default manner for the font backend and target device
			CAIRO_HINT_METRICS_OFF			Do not hint font metrics
			CAIRO_HINT_METRICS_ON				Hint font metrics
		*/
		cairo_font_options_set_hint_style(fontOptions, CAIRO_HINT_STYLE_DEFAULT);
		cairo_font_options_set_hint_metrics(fontOptions, CAIRO_HINT_METRICS_DEFAULT);
	}

	cairo_font_options_set_antialias(fontOptions, antiAliasFlag ? CAIRO_ANTIALIAS_GRAY : CAIRO_ANTIALIAS_NONE);
}

void computeLayout(PangoLayout *layout, char *utf8, int utf8Length, int *wPtr, int *hPtr, int *xOffsetPtr, int *yOffsetPtr, int *layoutDetailsPtr) {
	PangoRectangle inkRect, logicalRect;
	int left, top, right, bottom, baseline;
	PangoLayoutIter *iter;

	if (fontDescr == NULL) pango2SetFont("Verdana", 18, 0, 0, 1);
	pango_cairo_context_set_font_options(pango_layout_get_context(layout), fontOptions);
	if (language[0] != 0) pango_context_set_language(pango_layout_get_context(layout), pango_language_from_string(language));
	pango_layout_set_font_description(layout, fontDescr);
	pango_layout_set_text(layout, utf8, utf8Length);
	pango_layout_get_pixel_extents(layout, &inkRect, &logicalRect);

	left = (inkRect.x < logicalRect.x) ? inkRect.x : logicalRect.x;
	top = (inkRect.y < logicalRect.y) ? inkRect.y : logicalRect.y;
	right = inkRect.x + inkRect.width;
	if ((logicalRect.x + logicalRect.width) > right) right = logicalRect.x + logicalRect.width;
	bottom = inkRect.y + inkRect.height;
	if ((logicalRect.y + logicalRect.height) > bottom) bottom = logicalRect.y + logicalRect.height;

	iter = pango_layout_get_iter(layout);
	baseline = PANGO_PIXELS(pango_layout_iter_get_baseline(iter));
	pango_layout_iter_free(iter);

	if (left < 0) {
		inkRect.x = inkRect.x - left;
		logicalRect.x = logicalRect.x - left;
	}
	if (top < 0) {
		inkRect.y = inkRect.y - top;
		logicalRect.y = logicalRect.y - top;
		baseline = baseline - top;
	}

	if (layoutDetailsPtr != NULL) {
		layoutDetailsPtr[0] = inkRect.x;
		layoutDetailsPtr[1] = inkRect.y;
		layoutDetailsPtr[2] = inkRect.width;
		layoutDetailsPtr[3] = inkRect.height;
		
		layoutDetailsPtr[4] = logicalRect.x;
		layoutDetailsPtr[5] = logicalRect.y;
		layoutDetailsPtr[6] = logicalRect.width;
		layoutDetailsPtr[7] = logicalRect.height;

		layoutDetailsPtr[8] = baseline;
	}

	*wPtr =  right - left;
	*hPtr = bottom - top;
	*xOffsetPtr = left < 0 ? -left : 0;
	*yOffsetPtr =  top < 0 ? -top  : 0;
}

void pango2DrawString(char *utf8, int utf8Length, int *wPtr, int *hPtr, unsigned char *bitmapPtr) {
	int w = *wPtr;
	int h = *hPtr;
	int offsetX, offsetY;
	int *pixelPtr, *lastPtr;

	cairo_surface_t *surface = cairo_image_surface_create_for_data(bitmapPtr, CAIRO_FORMAT_RGB24, w, h, (4 * w));
	cairo_t *cr = cairo_create(surface);
	PangoLayout *layout = pango_cairo_create_layout(cr);

	computeLayout(layout, utf8, utf8Length, wPtr, hPtr, &offsetX, &offsetY, NULL);

	// fill with background color if not transparent
	if (bgRGB != 0) {
		cairo_set_source_rgb(cr, bgR, bgG, bgB);
		cairo_paint(cr);
	}

	cairo_translate(cr, offsetX, offsetY);
	cairo_set_source_rgb(cr, fgR, fgG, fgB);
	pango_cairo_show_layout(cr, layout);

	if (transparentBGFlag && (bgRGB != 0)) {
		pixelPtr = (int *) bitmapPtr;
		lastPtr = pixelPtr + (w * h);
		while (pixelPtr < lastPtr) {
			if (*pixelPtr == bgRGB) *pixelPtr = 0;
			pixelPtr++;
		}
	}

	g_object_unref(layout);
	cairo_destroy(cr);
	cairo_surface_destroy(surface);
}

void pango2MeasureString(char *utf8, int utf8Length, int *wPtr, int *hPtr, int *layoutDetailsPtr) {
	int offsetX, offsetY;

	if (cachedLayout == NULL) {
		cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_A8, 1, 1);
		cairo_t *cr = cairo_create(surface);
		cachedLayout = pango_cairo_create_layout(cr);
	}

	computeLayout(cachedLayout, utf8, utf8Length, wPtr, hPtr, &offsetX, &offsetY, layoutDetailsPtr);
}
