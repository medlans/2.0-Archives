#!/bin/sh
rm -f *.o PangoPlugin2
gcc -fPIC -Wall -c `pkg-config --cflags pangocairo` *.c
#ld -framework Carbon -bundle /usr/lib/bundle1.o *.o `pkg-config --libs pangocairo` -o PangoPlugin2 -flat_namespace
ld -bundle /usr/lib/bundle1.o *.o `pkg-config --libs pangocairo` -lc -o PangoPlugin2
rm -f *.o
