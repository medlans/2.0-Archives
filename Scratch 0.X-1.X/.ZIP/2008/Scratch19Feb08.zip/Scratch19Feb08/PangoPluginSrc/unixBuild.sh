#!/bin/sh
rm -f *.o PangoPlugin2
gcc -fPIC -Wall -c `pkg-config --cflags pangocairo` *.c
ld `pkg-config --libs pangocairo` -lc *.o -o PangoPlugin2
rm -f *.o
