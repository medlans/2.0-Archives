/* Automatically generated from Squeak on (24 January 2008 7:41:02 am) */

#if defined(WIN32) || defined(_WIN32) || defined(Win32)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT 
#endif /* WIN32 */

#include "sqVirtualMachine.h"

/* memory access macros */
#define byteAt(i) (*((unsigned char *) (i)))
#define byteAtput(i, val) (*((unsigned char *) (i)) = val)
#define longAt(i) (*((int *) (i)))
#define longAtput(i, val) (*((int *) (i)) = val)

void pango2DrawString(char *utf8, int utf8Length, int *wPtr, int *hPtr, unsigned char *bitmapPtr);
void pango2MeasureString(char *utf8, int utf8Length, int *wPtr, int *hPtr, int *layoutDetailsPtr);
void pango2SetColors(int fgRed, int fgGreen, int fgBlue, int bgRed, int bgGreen, int bgBlue, int mapBGToTransparent);
void pango2SetFont(char *fontName, int fontSize, int boldFlag, int italicFlag, int antiAliasFlag);
void pango2SetLanguage(char* lang);

/*** Variables ***/
struct VirtualMachine* interpreterProxy;
const char *moduleName = "PangoPlugin2 24 January 2008 (e)";

/*** Functions ***/
static char * cString(int stringOop);
static void * cWordsPtrminSize(int oop, int minSize);
static int copyStringintomax(int stringOop, char *stringPtr, int maxChars);
EXPORT int primitiveDrawString(void);
EXPORT int primitiveMeasureString(void);
EXPORT int primitiveMeasureString2(void);
EXPORT int primitiveSetColors(void);
EXPORT int primitiveSetFont(void);
EXPORT int primitiveSetLanguage(void);
EXPORT int setInterpreter(struct VirtualMachine* anInterpreter);

static char * cString(int stringOop) {
	if (((stringOop & 1)) || (!(interpreterProxy->isBytes(stringOop)))) {
		interpreterProxy->success(0);
		return 0;
	}
	return ((char *) (interpreterProxy->firstIndexableField(stringOop)));
}

static void * cWordsPtrminSize(int oop, int minSize) {
	interpreterProxy->success((!((oop & 1))) && ((interpreterProxy->isWords(oop)) && ((interpreterProxy->stSizeOf(oop)) >= minSize)));
	if (interpreterProxy->failed()) {
		return 0;
	}
	return ((void *) (interpreterProxy->firstIndexableField(oop)));
}

static int copyStringintomax(int stringOop, char *stringPtr, int maxChars) {
    char *srcPtr;
    int count;
    int i;

	if (((stringOop & 1)) || (!(interpreterProxy->isBytes(stringOop)))) {
		interpreterProxy->success(0);
		return 0;
	}
	count = interpreterProxy->stSizeOf(stringOop);
	if (!(count < maxChars)) {
		interpreterProxy->success(0);
		return 0;
	}
	srcPtr = ((char *) (interpreterProxy->firstIndexableField(stringOop)));
	for (i = 1; i <= count; i += 1) {
		*stringPtr++ = *srcPtr++;
	}
	*stringPtr = 0;
	return 0;
}

EXPORT int primitiveDrawString(void) {
    int bitmapOop;
    void *bitmapPtr;
    int result;
    int h;
    int utf8Oop;
    int w;
    int utf8Length;
    char *utf8;

	utf8Oop = interpreterProxy->stackValue(3);
	utf8 = cString(utf8Oop);
	w = interpreterProxy->stackIntegerValue(2);
	h = interpreterProxy->stackIntegerValue(1);
	bitmapOop = interpreterProxy->stackValue(0);
	bitmapPtr = cWordsPtrminSize(bitmapOop, w * h);
	if (interpreterProxy->failed()) {
		return 0;
	}
	utf8Length = interpreterProxy->stSizeOf(utf8Oop);
	pango2DrawString(utf8, utf8Length, &w, &h, bitmapPtr);
	result = interpreterProxy->makePointwithxValueyValue(w, h);
	interpreterProxy->popthenPush(5, result);
	return 0;
}

EXPORT int primitiveMeasureString(void) {
    int utf8Length;
    int result;
    int h;
    int utf8Oop;
    int w;
    char *utf8;

	utf8Oop = interpreterProxy->stackValue(0);
	utf8 = cString(utf8Oop);
	if (interpreterProxy->failed()) {
		return 0;
	}
	w = h = 0;
	utf8Length = interpreterProxy->stSizeOf(utf8Oop);
	pango2MeasureString(utf8, utf8Length, &w, &h, (int *) 0);
	result = interpreterProxy->makePointwithxValueyValue(w, h);
	interpreterProxy->popthenPush(2, result);
	return 0;
}

EXPORT int primitiveMeasureString2(void) {
    int result;
    int h;
    int utf8Oop;
    int w;
    int resultOop;
    int *resultPtr = 0;
    int utf8Length;
    char *utf8;

	utf8Oop = interpreterProxy->stackValue(1);
	utf8 = cString(utf8Oop);
	resultOop = interpreterProxy->stackValue(0);
	resultPtr = cWordsPtrminSize(resultOop, 9);
	if (interpreterProxy->failed()) {
		return 0;
	}
	w = h = 0;
	utf8Length = interpreterProxy->stSizeOf(utf8Oop);
	pango2MeasureString(utf8, utf8Length, &w, &h, resultPtr);
	result = interpreterProxy->makePointwithxValueyValue(w, h);
	interpreterProxy->popthenPush(3, result);
	return 0;
}

EXPORT int primitiveSetColors(void) {
    int fgGreen;
    int bgBlue;
    int fgBlue;
    int bgRed;
    int bgGreen;
    int mapBGToTransparent;
    int fgRed;

	fgRed = interpreterProxy->stackIntegerValue(6);
	fgGreen = interpreterProxy->stackIntegerValue(5);
	fgBlue = interpreterProxy->stackIntegerValue(4);
	bgRed = interpreterProxy->stackIntegerValue(3);
	bgGreen = interpreterProxy->stackIntegerValue(2);
	bgBlue = interpreterProxy->stackIntegerValue(1);
	mapBGToTransparent = interpreterProxy->booleanValueOf(interpreterProxy->stackValue(0));
	if (interpreterProxy->failed()) {
		return 0;
	}
	pango2SetColors(fgRed, fgGreen, fgBlue, bgRed, bgGreen, bgBlue, mapBGToTransparent);
	interpreterProxy->pop(7);
	return 0;
}

EXPORT int primitiveSetFont(void) {
    int boldFlag;
    int fontSize;
    char fontName[200];
    int antiAliasFlag;
    int italicFlag;

	copyStringintomax(interpreterProxy->stackValue(4), fontName, 200);
	fontSize = interpreterProxy->stackIntegerValue(3);
	boldFlag = interpreterProxy->booleanValueOf(interpreterProxy->stackValue(2));
	italicFlag = interpreterProxy->booleanValueOf(interpreterProxy->stackValue(1));
	antiAliasFlag = interpreterProxy->booleanValueOf(interpreterProxy->stackValue(0));
	if (interpreterProxy->failed()) {
		return 0;
	}
	pango2SetFont(fontName, fontSize, boldFlag, italicFlag, antiAliasFlag);
	interpreterProxy->pop(5);
	return 0;
}

EXPORT int primitiveSetLanguage(void) {
    char lang[100];

	copyStringintomax(interpreterProxy->stackValue(0), lang, 100);
	if (interpreterProxy->failed()) {
		return 0;
	}
	pango2SetLanguage(lang);
	interpreterProxy->pop(1);
	return 0;
}

EXPORT int setInterpreter(struct VirtualMachine* anInterpreter) {
    int ok;

	interpreterProxy = anInterpreter;
	ok = interpreterProxy->majorVersion() == VM_PROXY_MAJOR;
	if (ok == 0) {
		return 0;
	}
	ok = interpreterProxy->minorVersion() >= VM_PROXY_MINOR;
	return ok;
}
